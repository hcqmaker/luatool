/**
read a same name of exe config file one line and execute it
for example
    exe: my.exe, my.cfg
    my.cfg: lua.exe lua.lua
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

#define MAX_SZ 256

void parse_file_base_name(const char* path, char* basename)
{
    size_t sz = strlen(path);
    int e = -1,s = -1;
    int i = sz - 1;
    while (i >= 0)
    {
        if (path[i] == '.')
            e = i;
        else if (path[i] == '/' || path[i] == '\\')
        {
            s = i;
            break;
        }
        i--;
    }
    memcpy(basename, (path + s + 1), (e - s - 1));
}

void read_config_line(const char* fn, char* buff)
{
    FILE *fp = fopen(fn,"r");
    fgets(buff, MAX_SZ, fp);
    fclose(fp);
}

int main(int argc, char **argv)
{
    char configname[MAX_SZ] = {0};
    char basename[MAX_SZ] = {0};
    char buff[MAX_SZ] = {0};

    parse_file_base_name(argv[0], basename);
    sprintf(configname, "%s.cfg", basename);
    read_config_line(configname, buff);

    if (strlen(buff) > 0)
        WinExec(buff,SW_SHOWNORMAL);

    return 0;
}
